export type MessageRole = "user" | "assistant";
export type MessageStatus = "complete" | "streaming" | "error";

export interface ChatMessage {
  id: string;
  role: MessageRole;
  content: string;
  createdAt: string;
  status?: MessageStatus;
  errorCode?: ChatErrorCode;
}

export interface ChatConversation {
  id: string;
  title: string;
  createdAt: string;
  updatedAt: string;
  messages: ChatMessage[];
}

export type AppLanguage = "az" | "tr" | "en" | "ru";
export type AppTheme = "system" | "light" | "dark";
export type ResponseStyle = "concise" | "balanced" | "detailed";

export interface AppSettings {
  language: AppLanguage;
  theme: AppTheme;
  responseStyle: ResponseStyle;
  enterToSend: boolean;
  showTimestamps: boolean;
}

export type ChatErrorCode =
  | "MISSING_API_KEY"
  | "INVALID_API_KEY"
  | "RATE_LIMITED"
  | "NETWORK_ERROR"
  | "REQUEST_TIMEOUT"
  | "PROVIDER_UNAVAILABLE"
  | "EMPTY_RESPONSE"
  | "MESSAGE_TOO_LONG"
  | "INVALID_REQUEST"
  | "SERVER_ERROR";

export interface ChatApiError {
  code: ChatErrorCode;
  message: string;
}

export interface ChatRequestMessage {
  role: MessageRole;
  content: string;
}

export interface ChatRequestBody {
  messages: ChatRequestMessage[];
  language: AppLanguage;
  responseStyle: ResponseStyle;
}
