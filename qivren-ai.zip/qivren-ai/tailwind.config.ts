import type { Config } from "tailwindcss";

const config: Config = {
  darkMode: "class",
  content: [
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
    "./components/**/*.{js,ts,jsx,tsx,mdx}",
    "./lib/**/*.{js,ts,jsx,tsx,mdx}"
  ],
  theme: {
    extend: {
      fontFamily: {
        sans: ["var(--font-sans)", "Inter", "ui-sans-serif", "system-ui"]
      },
      boxShadow: {
        glow: "0 0 0 1px rgba(139,92,246,.12), 0 22px 60px rgba(25,16,54,.18)"
      },
      animation: {
        "fade-in": "fadeIn .2s ease-out",
        "slide-up": "slideUp .25s ease-out",
        "pulse-soft": "pulseSoft 1.5s ease-in-out infinite"
      },
      keyframes: {
        fadeIn: { from: { opacity: "0" }, to: { opacity: "1" } },
        slideUp: {
          from: { opacity: "0", transform: "translateY(8px)" },
          to: { opacity: "1", transform: "translateY(0)" }
        },
        pulseSoft: {
          "0%, 100%": { opacity: ".35" },
          "50%": { opacity: "1" }
        }
      }
    }
  },
  plugins: []
};

export default config;
